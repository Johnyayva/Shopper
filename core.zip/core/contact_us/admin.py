from django.contrib import admin

from .models import AboutOfice, Accordion, ContactUs


admin.site.register(AboutOfice)
admin.site.register(Accordion)
admin.site.register(ContactUs)